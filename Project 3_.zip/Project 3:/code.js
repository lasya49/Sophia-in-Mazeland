var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":[],"propsByKey":{}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var sophia=createSprite(390,390,15,15);
var cb1=createSprite(10,90,250,20);
var cb2=createSprite(99,15,100,20);
var cb3=createSprite(125,150,20,100);
var cb4=createSprite(190,190,140,20);
var cb5=createSprite(270,158,20,85);
var cb6=createSprite(190,5,20,250);
var cb7=createSprite(230,20,20,90);
var cb8=createSprite(5,150,90,20);
var cb9=createSprite(10,390,390,20);
var cb10=createSprite(5,370,150,20);
var cb11=createSprite(205,395,20,250);
var cb12=createSprite(160,290,100,20);
var cb13=createSprite(115,210,100,20);
var cb14=createSprite(60,220,15,53);
var cb15=createSprite(270,395,50,20);
var cb16=createSprite(350,390,20,200);
var cb17=createSprite(280,250,60,20);
var cb18=createSprite(395,190,80,20);
var cb19=createSprite(370,150,90,20);
var cb20=createSprite(395,5,15,200);
var cb21=createSprite(370,10,120,20);
var cb22=createSprite(350,50,70,20);
var cup=createSprite(10,53,15,53);
cup.shapeColor="orange";
sophia.shapeColor="white";
cb1.shapeColor="yellow";
cb2.shapeColor="yellow";
cb3.shapeColor="yellow";
cb4.shapeColor="yellow";
cb5.shapeColor="yellow";
cb6.shapeColor="yellow";
cb7.shapeColor="yellow";
cb8.shapeColor="yellow";
cb9.shapeColor="yellow";
cb10.shapeColor="yellow";
cb11.shapeColor="yellow";
cb12.shapeColor="yellow";
cb13.shapeColor="yellow";
cb14.shapeColor="yellow";
cb15.shapeColor="yellow";
cb16.shapeColor="yellow";
cb17.shapeColor="yellow";
cb18.shapeColor="yellow";
cb19.shapeColor="yellow";
cb20.shapeColor="yellow";
cb21.shapeColor="yellow";
cb22.shapeColor="yellow";
sophia.velocityX=0;
sophia.velocityY=0;

function draw(){
background("rgb(140,120,200)");
 createEdgeSprites();
 sophia.bounceOff(edges);
 sophia.bounceOff(cb1);
 sophia.bounceOff(cb2);
 sophia.bounceOff(cb3);
 sophia.bounceOff(cb4);
 sophia.bounceOff(cb5);
 sophia.bounceOff(cb6);
 sophia.bounceOff(cb7);
 sophia.bounceOff(cb8);
 sophia.bounceOff(cb9);
 sophia.bounceOff(cb10);
 sophia.bounceOff(cb11);
 sophia.bounceOff(cb12);
 sophia.bounceOff(cb13);
 sophia.bounceOff(cb14);
 sophia.bounceOff(cb15);
 sophia.bounceOff(cb16);
 sophia.bounceOff(cb17);
 sophia.bounceOff(cb18);
 sophia.bounceOff(cb19);
 sophia.bounceOff(cb20);
 sophia.bounceOff(cb21);
 sophia.bounceOff(cb22);
 drawSprites();
fill("red") ;
 text("CUP",10,15);
 text("SOPHIA",350,360);
 
  
 if (keyDown(UP_ARROW)) {
   sophia.velocityX=0;
   sophia.velocityY=-4;
 }
 
 if (keyDown(DOWN_ARROW)) {
  sophia.velocityX=0;
  sophia.velocityY=4;
  }
if (keyDown(LEFT_ARROW)) {
    sophia.velocityX=-5;
    sophia.velocityY=0;
  }
    
    if (keyDown(RIGHT_ARROW)) {
    
    sophia.velocityX=5;
    sophia.velocityY=0;
    }
  if (sophia.isTouching(cup)) 
  {
      fill("green");
  textFont("Impact");
  textSize(20);
    text("You Win!",170,150);
      sophia.velocityX=0;
      sophia.velocityY=0;
  }
  
  
    drawSprites();
 
 
  }
  
  drawSprites();

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
